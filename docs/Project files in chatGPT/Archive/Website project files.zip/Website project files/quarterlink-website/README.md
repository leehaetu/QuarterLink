# QuarterLink website

A complete multi-page marketing website for **QuarterLink — spreadsheet bridging software for Making Tax Digital for Income Tax quarterly updates**.

The site is built as a plain Node.js app with static HTML, CSS, and JavaScript. It is ready to open in VS Code, commit to GitHub, and deploy to Railway.

## What is included

- Landing page with hero, audience cards, workflow, deadlines, and call to action
- Product pages for individuals, landlords, agents, and practices
- How it works page covering template, linked summary sheet, read-only imports, and proof trail
- Pricing page for Individual, Plus, Agent, Practice, and final declaration / tax return add-on
- Security/proof trail page
- FAQ, contact, privacy, and terms pages
- Working form backend for `/start` and `/contact`
- Admin viewer at `/admin` protected by `ADMIN_TOKEN`
- Railway config file: `railway.toml`
- Smoke test script: `npm test`
- Temporary text/SVG logo that can be replaced with your real logo later

## Project structure

```text
quarterlink-website/
├── public/
│   ├── assets/
│   │   ├── admin.js
│   │   ├── favicon.svg
│   │   ├── forms.js
│   │   ├── main.js
│   │   ├── quarterlink-logo.svg
│   │   └── styles.css
│   ├── index.html
│   ├── how-it-works.html
│   ├── individuals.html
│   ├── landlords.html
│   ├── agents.html
│   ├── practice.html
│   ├── pricing.html
│   ├── security.html
│   ├── faq.html
│   ├── start.html
│   ├── contact.html
│   ├── admin.html
│   ├── privacy.html
│   ├── terms.html
│   └── 404.html
├── data/
├── server.mjs
├── test-smoke.mjs
├── package.json
├── railway.toml
├── Procfile
├── .env.example
└── .gitignore
```

## Run locally in VS Code

1. Unzip the folder.
2. Open the folder in VS Code.
3. Copy `.env.example` to `.env` if you want local environment values.
4. Run:

```bash
npm install
npm run dev
```

The site will run at:

```text
http://localhost:3000
```

Run smoke tests:

```bash
npm test
```

## Form submissions

The `/start` form posts to:

```text
POST /api/early-access
```

The `/contact` form posts to:

```text
POST /api/contact
```

By default, submissions are stored as newline-delimited JSON files:

```text
data/leads.ndjson
data/contacts.ndjson
```

For production, set `LEADS_WEBHOOK_URL` in Railway if you want every submission forwarded to another system such as a CRM, automation tool, or database endpoint.

The filesystem on many hosted platforms can be temporary. For permanent lead storage, use a Railway volume, a database, or the webhook option.

## Admin page

Set an admin token locally or in Railway:

```bash
ADMIN_TOKEN=replace-with-a-long-secret
```

Then visit:

```text
/admin
```

Enter the token to view captured lead and contact submissions.

## Deploy via GitHub and Railway

From the project folder:

```bash
git init
git add .
git commit -m "Initial QuarterLink website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/quarterlink-website.git
git push -u origin main
```

In Railway:

1. Create a new project.
2. Choose **Deploy from GitHub repo**.
3. Select the `quarterlink-website` repository.
4. Add environment variables:

```text
NODE_ENV=production
ADMIN_TOKEN=replace-with-a-long-secret
SITE_URL=https://your-railway-domain-or-custom-domain
LEADS_WEBHOOK_URL=optional-webhook-url
```

Railway will use `railway.toml` and run:

```bash
npm start
```

## Replace the temporary logo

The current logo is a clean SVG wordmark so the site works without your uploaded logo.

To replace it later, overwrite:

```text
public/assets/quarterlink-logo.svg
```

Keep the filename the same and the header/footer will update automatically. For the browser icon, replace:

```text
public/assets/favicon.svg
```

## Editing content

Most page content is in the HTML files under `/public`.

Key files:

- `public/index.html` — landing page
- `public/pricing.html` — plan names and prices
- `public/faq.html` — common customer questions
- `public/assets/styles.css` — design system and layout
- `server.mjs` — routing, API endpoints, admin data access, and static file serving

## Copy choices used

The site uses customer-facing wording such as:

- Making Tax Digital for Income Tax
- send quarterly updates
- quarterly updates
- spreadsheet records
- bridging software
- software that connects to records

The site avoids old or risky phrases such as:

- HMRC-approved
- HMRC-endorsed
- file quarterly tax returns
- submit quarterly returns
- End of Period Statement

## Notes before commercial launch

- Replace privacy and terms pages with final legal copy.
- Confirm final pricing.
- Connect form submissions to permanent storage or CRM.
- Replace the temporary logo with your real brand asset.
- Add analytics only after choosing a compliant analytics/cookie approach.
