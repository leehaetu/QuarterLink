import http from 'node:http';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDir = path.join(__dirname, 'public');
const dataDir = path.join(__dirname, 'data');
const port = Number(process.env.PORT || 3000);
const siteUrl = process.env.SITE_URL || `http://localhost:${port}`;

const mimeTypes = new Map([
  ['.html', 'text/html; charset=utf-8'],
  ['.css', 'text/css; charset=utf-8'],
  ['.js', 'application/javascript; charset=utf-8'],
  ['.json', 'application/json; charset=utf-8'],
  ['.svg', 'image/svg+xml'],
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.ico', 'image/x-icon'],
  ['.txt', 'text/plain; charset=utf-8'],
  ['.webmanifest', 'application/manifest+json; charset=utf-8']
]);

const routeMap = new Map([
  ['/', 'index.html'],
  ['/how-it-works', 'how-it-works.html'],
  ['/individuals', 'individuals.html'],
  ['/landlords', 'landlords.html'],
  ['/agents', 'agents.html'],
  ['/practice', 'practice.html'],
  ['/pricing', 'pricing.html'],
  ['/security', 'security.html'],
  ['/faq', 'faq.html'],
  ['/start', 'start.html'],
  ['/contact', 'contact.html'],
  ['/admin', 'admin.html'],
  ['/privacy', 'privacy.html'],
  ['/terms', 'terms.html']
]);

function send(res, statusCode, body, headers = {}) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'X-Content-Type-Options': 'nosniff',
    ...headers
  });
  res.end(typeof body === 'string' ? body : JSON.stringify(body));
}

function sendHtml(res, statusCode, body, contentType = 'text/html; charset=utf-8') {
  res.writeHead(statusCode, {
    'Content-Type': contentType,
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': statusCode === 200 ? 'public, max-age=300' : 'no-store'
  });
  res.end(body);
}

async function readBody(req, maxBytes = 1_000_000) {
  let body = '';
  for await (const chunk of req) {
    body += chunk;
    if (body.length > maxBytes) {
      throw new Error('Payload too large');
    }
  }
  if (!body) return {};
  try {
    return JSON.parse(body);
  } catch {
    throw new Error('Invalid JSON payload');
  }
}

function cleanText(value, max = 500) {
  return String(value ?? '').trim().replace(/\s+/g, ' ').slice(0, max);
}

function isEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || '').trim());
}

function clientIp(req) {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string' && forwarded) return forwarded.split(',')[0].trim();
  return req.socket.remoteAddress || '';
}

async function appendLead(kind, payload, req) {
  await fs.mkdir(dataDir, { recursive: true });

  const lead = {
    id: crypto.randomUUID(),
    kind,
    createdAt: new Date().toISOString(),
    name: cleanText(payload.name, 120),
    email: cleanText(payload.email, 160).toLowerCase(),
    phone: cleanText(payload.phone, 80),
    organisation: cleanText(payload.organisation, 160),
    role: cleanText(payload.role, 120),
    incomeSources: Array.isArray(payload.incomeSources)
      ? payload.incomeSources.map((item) => cleanText(item, 80)).filter(Boolean).slice(0, 12)
      : [],
    tier: cleanText(payload.tier, 80),
    spreadsheetRoute: cleanText(payload.spreadsheetRoute, 120),
    clients: cleanText(payload.clients, 80),
    message: cleanText(payload.message, 1200),
    consent: Boolean(payload.consent),
    sourcePath: cleanText(payload.sourcePath, 160),
    userAgent: cleanText(req.headers['user-agent'], 300),
    ipHash: crypto.createHash('sha256').update(clientIp(req) || 'unknown').digest('hex')
  };

  if (!lead.name) throw new Error('Name is required');
  if (!isEmail(lead.email)) throw new Error('A valid email address is required');
  if (!lead.consent) throw new Error('Consent is required');

  const fileName = path.join(dataDir, `${kind}.ndjson`);
  await fs.appendFile(fileName, `${JSON.stringify(lead)}\n`, 'utf8');

  if (process.env.LEADS_WEBHOOK_URL) {
    try {
      await fetch(process.env.LEADS_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(lead)
      });
    } catch (error) {
      console.error('Lead webhook failed:', error.message);
    }
  }

  return lead;
}

async function readNdjson(fileName) {
  try {
    const raw = await fs.readFile(path.join(dataDir, fileName), 'utf8');
    return raw.split('\n').filter(Boolean).map((line) => JSON.parse(line));
  } catch (error) {
    if (error.code === 'ENOENT') return [];
    throw error;
  }
}

async function serveStatic(req, res, pathname) {
  let requested = pathname;
  if (routeMap.has(pathname)) {
    requested = `/${routeMap.get(pathname)}`;
  } else if (!path.extname(pathname) && routeMap.has(pathname.replace(/\/$/, ''))) {
    requested = `/${routeMap.get(pathname.replace(/\/$/, ''))}`;
  }

  const resolved = path.normalize(path.join(publicDir, requested));
  if (!resolved.startsWith(publicDir)) {
    send(res, 403, { error: 'Forbidden' });
    return;
  }

  try {
    const stat = await fs.stat(resolved);
    const filePath = stat.isDirectory() ? path.join(resolved, 'index.html') : resolved;
    const ext = path.extname(filePath).toLowerCase();
    const contentType = mimeTypes.get(ext) || 'application/octet-stream';
    const file = await fs.readFile(filePath);
    res.writeHead(200, {
      'Content-Type': contentType,
      'X-Content-Type-Options': 'nosniff',
      'Cache-Control': ext === '.html' ? 'public, max-age=300' : 'public, max-age=86400'
    });
    res.end(file);
  } catch (error) {
    try {
      const notFound = await fs.readFile(path.join(publicDir, '404.html'), 'utf8');
      sendHtml(res, 404, notFound);
    } catch {
      send(res, 404, { error: 'Page not found' });
    }
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', siteUrl);
    const pathname = url.pathname.replace(/\/$/, '') || '/';

    if (req.method === 'GET' && pathname === '/health') {
      send(res, 200, { status: 'ok', service: 'QuarterLink website', time: new Date().toISOString() });
      return;
    }

    if (req.method === 'POST' && (pathname === '/api/early-access' || pathname === '/api/contact')) {
      const payload = await readBody(req);
      const kind = pathname.endsWith('contact') ? 'contacts' : 'leads';
      const lead = await appendLead(kind, payload, req);
      send(res, 201, {
        ok: true,
        id: lead.id,
        message: kind === 'contacts'
          ? 'Thanks — your message has been received.'
          : 'Thanks — your QuarterLink request has been received.'
      });
      return;
    }

    if (req.method === 'GET' && pathname === '/api/leads') {
      const configuredToken = process.env.ADMIN_TOKEN;
      const suppliedToken = url.searchParams.get('token') || req.headers['x-admin-token'];
      if (!configuredToken || suppliedToken !== configuredToken) {
        send(res, 401, { error: 'Admin token required' });
        return;
      }
      const leads = await readNdjson('leads.ndjson');
      const contacts = await readNdjson('contacts.ndjson');
      send(res, 200, { leads, contacts });
      return;
    }

    if (req.method === 'GET' || req.method === 'HEAD') {
      await serveStatic(req, res, pathname);
      return;
    }

    send(res, 405, { error: 'Method not allowed' });
  } catch (error) {
    const status = error.message === 'Payload too large' ? 413 : 400;
    send(res, status, { error: error.message || 'Request failed' });
  }
});

server.listen(port, () => {
  console.log(`QuarterLink website running at ${siteUrl}`);
});
