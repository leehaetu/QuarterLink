(function () {
  const form = document.querySelector('[data-admin-form]');
  const output = document.querySelector('[data-admin-output]');
  if (!form || !output) return;

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, (char) => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    }[char]));
  }

  function renderRows(items) {
    if (!items.length) return '<p class="notice">No records found yet.</p>';
    return `
      <div class="admin-table-wrap">
        <table class="admin-table">
          <thead><tr><th>Date</th><th>Name</th><th>Email</th><th>Tier</th><th>Income sources</th><th>Message</th></tr></thead>
          <tbody>
            ${items.map((item) => `
              <tr>
                <td>${escapeHtml(item.createdAt)}</td>
                <td>${escapeHtml(item.name)}<br><small>${escapeHtml(item.organisation || item.role)}</small></td>
                <td>${escapeHtml(item.email)}<br><small>${escapeHtml(item.phone)}</small></td>
                <td>${escapeHtml(item.tier || item.spreadsheetRoute)}</td>
                <td>${escapeHtml((item.incomeSources || []).join(', '))}</td>
                <td>${escapeHtml(item.message)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const token = new FormData(form).get('token');
    output.innerHTML = '<p class="notice">Loading lead records…</p>';
    try {
      const response = await fetch(`/api/leads?token=${encodeURIComponent(token)}`);
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Admin request failed');
      output.innerHTML = `
        <h2>Early access requests</h2>
        ${renderRows(result.leads || [])}
        <h2 style="margin-top: 32px;">Contact messages</h2>
        ${renderRows(result.contacts || [])}
      `;
    } catch (error) {
      output.innerHTML = `<p class="notice"><strong>Could not load records.</strong> ${escapeHtml(error.message)}</p>`;
    }
  });
}());
