(function () {
  function status(form, message, isError = false) {
    const box = form.querySelector('[data-form-status]');
    if (!box) return;
    box.textContent = message;
    box.classList.toggle('error', Boolean(isError));
    box.classList.add('show');
  }

  function collectForm(form) {
    const data = new FormData(form);
    const payload = {};
    for (const [key, value] of data.entries()) {
      if (payload[key]) {
        if (!Array.isArray(payload[key])) payload[key] = [payload[key]];
        payload[key].push(value);
      } else {
        payload[key] = value;
      }
    }
    payload.incomeSources = data.getAll('incomeSources');
    payload.consent = data.get('consent') === 'yes';
    payload.sourcePath = window.location.pathname;
    return payload;
  }

  async function submitForm(form) {
    const endpoint = form.getAttribute('data-endpoint') || '/api/early-access';
    const payload = collectForm(form);
    const submit = form.querySelector('[type="submit"]');
    const originalText = submit?.textContent;

    if (!payload.name || !payload.email || !payload.consent) {
      status(form, 'Please add your name, email address, and consent before sending.', true);
      return;
    }

    submit?.setAttribute('disabled', 'disabled');
    if (submit) submit.textContent = 'Sending…';

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'The form could not be sent.');
      form.reset();
      status(form, result.message || 'Thanks — your request has been received.');
    } catch (error) {
      try {
        const saved = JSON.parse(localStorage.getItem('quarterlinkLocalSubmissions') || '[]');
        saved.push({ ...payload, createdAt: new Date().toISOString() });
        localStorage.setItem('quarterlinkLocalSubmissions', JSON.stringify(saved));
        status(form, 'Saved locally because the server endpoint was not available. Run the Node server or deploy to Railway to capture it centrally.', true);
      } catch {
        status(form, error.message || 'The form could not be sent.', true);
      }
    } finally {
      submit?.removeAttribute('disabled');
      if (submit && originalText) submit.textContent = originalText;
    }
  }


  const tierFromQuery = new URLSearchParams(window.location.search).get('tier');
  if (tierFromQuery) {
    const tierMap = { individual: 'Individual', plus: 'Plus', agent: 'Agent', practice: 'Practice' };
    document.querySelectorAll('select[name="tier"]').forEach((select) => {
      select.value = tierMap[tierFromQuery.toLowerCase()] || select.value;
    });
  }

  document.querySelectorAll('form[data-quarterlink-form]').forEach((form) => {
    form.addEventListener('submit', (event) => {
      event.preventDefault();
      submitForm(form);
    });
  });
}());
