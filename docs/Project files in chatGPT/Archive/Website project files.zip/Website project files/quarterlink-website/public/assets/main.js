(function () {
  const nav = document.querySelector('[data-nav]');
  const navToggle = document.querySelector('[data-nav-toggle]');
  if (nav && navToggle) {
    navToggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });
  }

  const currentPath = window.location.pathname.replace(/\/$/, '') || '/';
  document.querySelectorAll('.primary-nav a, .footer-grid a').forEach((link) => {
    const href = link.getAttribute('href');
    if (!href) return;
    const normalized = href.replace(/\/$/, '') || '/';
    if (normalized === currentPath) link.setAttribute('aria-current', 'page');
  });

  document.querySelectorAll('[data-year]').forEach((select) => {
    const currentYear = new Date().getFullYear();
    const taxYearStart = new Date().getMonth() >= 3 ? currentYear : currentYear - 1;
    for (let year = taxYearStart; year <= taxYearStart + 4; year += 1) {
      const option = document.createElement('option');
      option.value = String(year);
      option.textContent = `${year} to ${year + 1}`;
      select.appendChild(option);
    }
    select.value = String(taxYearStart);
    select.addEventListener('change', renderDeadlines);
  });

  function renderDeadlines() {
    document.querySelectorAll('[data-deadline-grid]').forEach((grid) => {
      const select = document.querySelector('[data-year]');
      const startYear = Number(select?.value || new Date().getFullYear());
      const quarters = [
        { q: 'Q1', period: `6 April ${startYear} to 5 July ${startYear}`, deadline: `7 August ${startYear}` },
        { q: 'Q2', period: `6 July ${startYear} to 5 October ${startYear}`, deadline: `7 November ${startYear}` },
        { q: 'Q3', period: `6 October ${startYear} to 5 January ${startYear + 1}`, deadline: `7 February ${startYear + 1}` },
        { q: 'Q4', period: `6 January ${startYear + 1} to 5 April ${startYear + 1}`, deadline: `7 May ${startYear + 1}` }
      ];
      grid.innerHTML = quarters.map((item) => `
        <article class="deadline-card">
          <strong>${item.q} period</strong>
          <span>${item.period}</span>
          <div class="deadline-date">Deadline: ${item.deadline}</div>
        </article>
      `).join('');
    });
  }
  renderDeadlines();

  const calculators = document.querySelectorAll('[data-pricing-calculator]');
  calculators.forEach((calculator) => {
    const clientInput = calculator.querySelector('[data-clients]');
    const result = calculator.querySelector('[data-price-result]');
    const update = () => {
      const clients = Math.max(0, Number(clientInput?.value || 0));
      const monthly = 49 + clients * 4;
      if (result) result.textContent = `Agent estimate: £${monthly}/month for ${clients} client${clients === 1 ? '' : 's'}.`;
    };
    clientInput?.addEventListener('input', update);
    update();
  });

  document.querySelectorAll('[data-copy]').forEach((button) => {
    button.addEventListener('click', async () => {
      const text = button.getAttribute('data-copy') || '';
      try {
        await navigator.clipboard.writeText(text);
        button.textContent = 'Copied';
        setTimeout(() => { button.textContent = 'Copy'; }, 1600);
      } catch {
        button.textContent = 'Select and copy';
      }
    });
  });
}());
