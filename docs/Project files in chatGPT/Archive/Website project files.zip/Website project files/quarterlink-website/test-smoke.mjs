import { spawn } from 'node:child_process';
import assert from 'node:assert/strict';

const port = 4179;
const child = spawn(process.execPath, ['server.mjs'], {
  cwd: new URL('.', import.meta.url),
  env: { ...process.env, PORT: String(port), SITE_URL: `http://localhost:${port}`, ADMIN_TOKEN: 'test-token' },
  stdio: ['ignore', 'pipe', 'pipe']
});

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function request(path, options = {}) {
  const response = await fetch(`http://localhost:${port}${path}`, options);
  const text = await response.text();
  return { response, text };
}

try {
  await wait(700);
  const health = await request('/health');
  assert.equal(health.response.status, 200);
  assert.match(health.text, /ok/);

  for (const page of ['/', '/how-it-works', '/individuals', '/landlords', '/agents', '/practice', '/pricing', '/security', '/faq', '/start', '/contact']) {
    const result = await request(page);
    assert.equal(result.response.status, 200, `${page} should be 200`);
    assert.match(result.text, /QuarterLink/);
  }

  const lead = await request('/api/early-access', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Smoke Test', email: 'smoke@example.com', consent: true, incomeSources: ['Self-employment'], tier: 'Individual' })
  });
  assert.equal(lead.response.status, 201);
  assert.match(lead.text, /received/);

  const admin = await request('/api/leads?token=test-token');
  assert.equal(admin.response.status, 200);
  assert.match(admin.text, /Smoke Test/);

  console.log('Smoke tests passed.');
} finally {
  child.kill('SIGTERM');
}
